default_fps = 30
base_duration = 0.2

pencil_padding = 107

default_page_last_pose = 2

note_line_heigh = 114

bg_image_path = "asset/bg.png"

font_path = "M_PLUS_Rounded_1c/MPLUSRounded1c-Medium.ttf"